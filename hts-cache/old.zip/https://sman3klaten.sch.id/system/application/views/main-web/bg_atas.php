 <!DOCTYPE html>
<html lang="en">
     <head>
     <title>SMA N 3 Klaten</title>
     <link rel="icon" href="