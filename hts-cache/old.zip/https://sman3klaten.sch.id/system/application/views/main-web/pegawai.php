    <div class="col-2-4">
    <div class="wrap-col">
    <div class="news mb0">
    <h2 class='head2'>Data Pegawai SMA N 3 Klaten</h2>
			<!--<img src="