
    <div class="col-2-4">
    <div class="wrap-col">
    <div class="news mb0">
    <h2 class='head2 ijo'>Album Galeri Kegiatan</h2>
		<b>Share this article on :			<script language="javascript">
				document.write("<a href='http://twitter.com/home/?status=" 
				+ document.URL + "' target='_blank'>&#8226; Twitter</a> | <a href='http://www.facebook.com/share.php?u=" 
				+ document.URL + "' target='_blank'>&#8226; Facebook</a> | <a href='http://www.reddit.com/submit?url=" 
				+ document.URL + "' target='_blank'>&#8226; Reddit</a> | <a href='http://digg.com/submit?url=" 
				+ document.URL + "' target='_blank'>&#8226; Digg</a>");
			</script>
			</b><br><br>