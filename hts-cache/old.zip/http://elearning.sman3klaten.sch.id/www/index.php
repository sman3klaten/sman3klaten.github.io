
	    <html>
	    <body>
	    <head>
	    <meta http-equiv = "Content-Type"     content = "text/html; charset = utf-8">
	    </head>
	    <style>
	    .singleMessage{width:100%;font-family:trebuchet ms;font-size:14px;border:1px solid red;background-color:#ffcccc;margin-top:10px}
	    .singleMessage td{padding:10px;}
	    .singleMessage td:first-child{width:1%}
	    </style>
	    <table class = "singleMessage">
	    	<tr><td><img src = "http://elearning.sman3klaten.sch.id/elearning/www//themes/default/images/32x32/warning.png" alt = "Failure" title = "Failure"></td>
	    		<td><div style = "font-size:16px;font-weight:bold">An error occured:</div><div>mysqli error: [1045: Access denied for user 's3fkS9Eut3'@'103.247.9.8' (using password: YES)] in CONNECT(remotemysql.com, 's3fkS9Eut3', '****', s3fkS9Eut3)
 (1045)</div></tr>
	    </table>
	    </body>
	    </html>
	    