<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Aplikasi Sistem Informasi Kenaikan SMA NEGERI 3 KLATEN</title>
    <link rel="stylesheet" href="css/bootstrap.css" media="screen">
    <link rel="stylesheet" href="css/bootswatch.min.css">
    <script type="text/javascript" async="" src="js/ga.js"></script>
    <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootswatch.js"></script>
</head>

<body>
<div class="navbar navbar-default navbar-fixed-top">
  <div class="container">
        <div class="navbar-header">
          <a href="index.php" class="navbar-brand">ASIK</a>
          <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div class="navbar-collapse collapse" id="navbar-main">
          <ul class="nav navbar-nav">
            <li>
              <a href="index.php?page=home">Beranda</a>
            </li>
            <li>
              <a href="index.php?page=about">About</a>
            </li>
            <li>
              <a href="index.php?page=panduan">Panduan & Pengumuman</a>
            </li>
            <li>
              <a href="index.php?page=contact">Hubungi Kami</a>
            </li>
            <li>
              <a href="index.php?page=login">Login</a>
            </li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="http://sman3klaten.sch.id/" target="_blank">Developed by Team TI SMA N 3 Klaten</a></li>
            </ul>
        </div>
  </div>
      </div>
     <table width="600" align="center">
  <tr>
    <td>
      <html>
<head>
<title> Halaman Pencarian </title>
</head>
<body>
<br><center>
<img src="images/logosmaga.png" height="180"></center>
<br>
<h3 align="center">Selamat datang di Aplikasi Sistem Informasi Kelulusan SMA NEGERI 3 KLATEN</h3>
<div id="formlulus" class="well" style="display:none;">
<div align="right"><SCRIPT language=JavaScript src="js/almanak.js"></SCRIPT> 
          <span class="style1">I</span> <SCRIPT language=JavaScript>var d = new Date();
var h = d.getHours();
if (h < 11) { document.write("Selamat pagi, Peserta Didik"); }
else { if (h < 15) { document.write("Selamat siang, Peserta Didik"); }
else { if (h < 19) { document.write("Selamat sore, Peserta Didik"); }
else { if (h <= 23) { document.write("Selamat malam, Peserta Didik"); }
}}}</SCRIPT>   </div><br/>
<script>
function cekNo() {
   var cek = document.forms["formcarino"]["noujian"].value;
     if(cek==null || cek=="")
     {
       alert("Nomor Induk Siswa Nasional (NISN) harus di isi dahulu!");
       return false;
     }
}
</script>
<form class="form-horizontal" form name="formcarino" method="post" action="index.php?page=searchno" onSubmit="return cekNo()">
<fieldset>
  <div align="center">
    <legend> Cari Berdasarkan Nomor Induk Siswa Nasional (NISN) Anda </legend>
  </div>
  <div class="form-group">
      <label for="noujian" class="col-lg-2 control-label">NISN</label>
      <div class="col-lg-10">
        <input type="text" class="form-control" name="noujian" placeholder="Contoh : 12345678" size="30">
      </div>
  </div>
    <div class="form-group">
      <div class="col-lg-10 col-lg-offset-2">
        <input type="SUBMIT" name="SUBMIT" id="SUBMIT" value="Cari" class="btn btn-primary"> Lupa Nomor Induk Siswa Nasional (NISN) Anda? klik <a href="index.php?page=contact2">disini</a>
      </div>
    </div>
</fieldset>
</form>
</div>
<table width="400" align="center">
  <tr>
    <td>
      <div align="center" class="alert alert-dismissable alert-danger">
<h4>
<script language="JavaScript">
TargetDate = "05/05/2023 04:30 PM";
BackColor = "";
ForeColor = "";
CountActive = true;
CountStepper = -1;
LeadingZero = true;
DisplayFormat = "%%D%% Hari, %%H%% Jam, %%M%% Menit, %%S%% Detik Lagi, Menuju Waktu Pengumuman";
FinishMessage = " == Pengumuman sudah bisa diakses == ";
</script>
<script language="JavaScript" src="js/countdown.js"></script>
</h4>
</div> 
      </td>
  </tr>
</table>
</body>
</html>      </td>
  </tr>
</table>
</body>
</html>