
    <div class="col-2-4">
    <div class="wrap-col">
    <div class="news">
		