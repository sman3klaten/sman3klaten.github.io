 <div class="row">
    <div class="bottom_block">
      <div class="col-1-2">
        <h2 class="head2 ijo">    
        Bergabung Dengan Sosial SMA N 3 klaten</h2>
        <div class="socials">
          <a href="https://twitter.com/SMAN3klaten" target="_blank" title="SMAN 3 KLATEN">
          <h6 class="ijo">
            <br><br><br><br>
            SMA N 3 Klaten
            </h6>
          </a>
          <a href="https://twitter.com/OSMAGAKlaten" target="_blank" title="OSIS SMAN 3 KLATEN">
          	<h6 class="ijo">
            <br><br><br><br>
            OSIS SMA N 3 
            </h6>
          </a>
        </div>
        <div class="socials">
           <a href="https://twitter.com/DA_smaga" target="_blank" title="Dewan Ambalan SMAN 3 KLATEN">
           	<h6 class="ijo">
            <br><br><br><br>
            Dewan Ambalan
            </h6>
           </a>
          <a href="https://twitter.com/pretana_berawa" target="_blank" title="Pretana Berawa">
          	<h6 class="ijo">
            <br><br><br><br>
            Pretana Berawa
            </h6>	
          </a>
        </div>
      </div>
      <div class="col-1-2">
        <h2 class=" head2 ijo">Galeri Kegiatan</h2>
          