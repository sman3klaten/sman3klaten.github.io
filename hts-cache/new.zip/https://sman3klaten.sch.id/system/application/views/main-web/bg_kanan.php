<div class="col-1-4">
  <div class="wrap-col">
      <h2 class="head2 ijo">
      <div class="judul">Jajak Pendapat</div></h2>
      <div class="kotak">
        <form method="post" action="