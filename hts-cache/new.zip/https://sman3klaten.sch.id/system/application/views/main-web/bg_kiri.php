  <div class="content">
   <div class="zerogrid">
    <div class="row">

	<div class="col-1-4">
	  <div class="wrap-col">
	      <h2 class="head2 ijo">
	      <div class="judul">Main Menu</div></h2>
	      <div class="kotak">
	      <ul class="list">
	          