     <div class="col-2-4">
    <div class="wrap-col">
      <h2 class="head2 ijo">Selamat Datang di Website SMA N 3 Klaten </h2>
      <div class="news">
        <img src="